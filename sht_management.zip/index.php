<?php

// connection
include_once("config/connection.php");

// Helpers
include_once("config/helpers.php");

include_once("routes/web.php");
