<?php

// echo "<pre>";
// print_r($data);
// exit;
// header
include_view("layouts/header");

// sidebar
include_view("layouts/sidebar");
?>

<!-- content here start -->
<div class="crms-title row bg-white">
    <div class="col  p-0">
        <h3 class="page-title m-0">
            <span class="page-title-icon bg-gradient-primary text-white me-2">
                <i class="feather-check-square"></i>
            </span> Tasks
        </h3>
    </div>
    <div class="col p-0 text-end">
        <ul class="breadcrumb bg-white float-end m-0 ps-0 pe-0">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Task</li>
        </ul>
    </div>
</div>

<!-- Page Header -->
<div class="page-header pt-3 mb-0 ">
    <div class="row">
        <div class="col">
            <div class="dropdown">
                <a class="dropdown-toggle recently-viewed" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> All Tasks </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Items I'm following</a>
                    <a class="dropdown-item" href="#">All Completed Tasks</a>
                    <a class="dropdown-item" href="#">My Delegated Tasks</a>
                    <a class="dropdown-item" href="#">My Completed Tasks</a>
                    <a class="dropdown-item" href="#">My Open Tasks</a>
                    <a class="dropdown-item" href="#">My Tasks</a>
                    <a class="dropdown-item" href="#">All Tasks</a>
                </div>
            </div>
        </div>
        <div class="col text-end">
            <ul class="list-inline-item ps-0">
                <li class="nav-item dropdown list-inline-item add-lists">
                    <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="nav-profile-text">
                            <i class="fa fa-th" aria-hidden="true"></i>
                        </div>
                    </a>
                    <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#add-new-list">Add New
                            List View</a>
                    </div>
                </li>
                <li class="list-inline-item">
                    <!-- <a href="<?= route("tasks/add"); ?>"
                        class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded"
                        id="add-task">New Task</a> -->
                    <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded" id="add-task" data-bs-toggle="modal" data-bs-target="#add_task">New Task</button>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Page Header -->


<!-- Content Starts -->
<div class="row">
    <div class="col-md-12">
        <div class="card mb-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-nowrap custom-table mb-0 datatable">
                        <thead>
                            <tr>
                                <th class="checkBox">
                                    <label class="container-checkbox">
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                    </label>
                                </th>
                                <th>Project Name</th>
                                <th>Task Name</th>
                                <th>Description</th>
                                <th>Task Assign</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Due Date</th>
                                <th>Edit</th>
                                <th>Delete</th>
                                <!-- <th class="text-end">Actions</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            if (!empty($data)) {
                                foreach ($data['tasks'] as $tasks) { ?>
                                    <tr>
                                        <td class="checkBox">
                                            <label class="container-checkbox">
                                                <input type="checkbox" name="tasks" value="<?= $tasks['id'] ?>">
                                                <span class="checkmark"></span>
                                            </label>
                                        </td>
                                        <td>
                                            <?php
                                            $crud = new Models("projects");
                                            $project = $crud->read("id", $tasks['project_id']);
                                            echo $project['name'];
                                            ?>
                                        </td>
                                        <td>
                                            <?= $tasks['name'] ?>
                                        </td>
                                        <td>
                                            <?= $tasks['description'] ?>
                                        </td>
                                        <td>
                                            <?php
                                            $crud = new Models("users");
                                            $users = $crud->read("id", $tasks['assigned_to']);
                                            echo $users['username'];
                                            ?>
                                        </td>
                                        <td>
                                            <?= $tasks['priority'] ?>
                                        </td>
                                        <td>
                                            <?= $tasks['status'] ?>
                                        </td>
                                        <td>
                                            <?= $tasks['due_date'] ?>
                                        </td>
                                        <td>
                                            <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded" data-bs-toggle="modal" id="edit-btn" data-bs-target="#edit-modal" data-eid="<?= $tasks['id'] ?>" onclick="selectOptions()">Edit</button>
                                        </td>
                                        <td>
                                            <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded delete-btn" data-id="<?= $tasks['id'] ?>">Delete</button>
                                        </td>

                                    </tr>
                            <?php }
                            }

                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Content End -->
<!-- content here end -->




<!-- Models Start -->
<?php
// footer
// include_view("tasks/models");
include_view("tasks/models", $data);
?>
<!-- Models eMD -->



<?php
// yield_data("content");
// footer
include_view("layouts/footer");
?>