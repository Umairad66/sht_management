<?php

// echo "<pre>";
// print_r($data);
// exit;

// header
include_view("layouts/header");

// sidebar
include_view("layouts/sidebar");
?>

<!-- content here start -->
<div class="crms-title row bg-white">
    <div class="col  p-0">
        <h3 class="page-title m-0">
            <span class="page-title-icon bg-gradient-primary text-white me-2">
                <i class="feather-check-square"></i>
            </span> Projects
        </h3>
    </div>
    <div class="col p-0 text-end">
        <ul class="breadcrumb bg-white float-end m-0 ps-0 pe-0">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Projects</li>
        </ul>
    </div>
</div>

<!-- Page Header -->
<div class="page-header pt-3 mb-0 ">
    <div class="row">
        <div class="col">
            <div class="dropdown">
                <a class="dropdown-toggle recently-viewed" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> All Projects </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Items I'm following</a>
                    <a class="dropdown-item" href="#">All Completed Projects</a>
                    <a class="dropdown-item" href="#">My Delegated Projects</a>
                    <a class="dropdown-item" href="#">My Completed Projects</a>
                    <a class="dropdown-item" href="#">My Open Projects</a>
                    <a class="dropdown-item" href="#">My Projects</a>
                    <a class="dropdown-item" href="#">All Projects</a>
                </div>
            </div>
        </div>
        <div class="col text-end">
            <ul class="list-inline-item ps-0">
                <li class="nav-item dropdown list-inline-item add-lists">
                    <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="nav-profile-text">
                            <i class="fa fa-th" aria-hidden="true"></i>
                        </div>
                    </a>
                    <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#add-new-list">Add New
                            List View</a>
                    </div>
                </li>
                <li class="list-inline-item">

                    <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded" data-bs-toggle="modal" data-bs-target="#add-projects">Add Projects</button>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Page Header -->


<!-- Content Starts -->
<div class="row">
    <div class="col-md-12">
        <div class="card mb-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-nowrap custom-table mb-0 datatable">
                        <thead>
                            <tr>
                                <th class="checkBox">
                                    <label class="container-checkbox">
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                    </label>
                                </th>
                                <th>Project Name</th>
                                <th>Description</th>
                                <th>Manager_id</th>
                                <th>Team_ids</th>
                                <th>Status</th>
                                <th>Priority</th>
                                <!-- <th>Created_at </th>
                                <th>Updated_at</th> -->
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            if (!empty($data['projects'])) {
                                foreach ($data['projects'] as $projects) {
                            ?>

                                    <tr>
                                        <td class="checkBox">
                                            <label class="container-checkbox">
                                                <input type="checkbox" name="tasks" value="<?= $projects['id'] ?>">
                                                <span class="checkmark"></span>
                                            </label>
                                        </td>

                                        <td>
                                            <?= $projects['name'] ?>
                                        </td>
                                        <td>
                                            <?= $projects['description'] ?>
                                        </td>

                                        <td>
                                            <?php
                                                echo $_SESSION['auth']['username'];
                                            ?>
                                        </td>

                                        <td>
                                        <?php
                                            $crud = new Models("users");
                                            $users = $crud->read("id", $tasks['assigned_to']);
                                            echo $users['username'];
                                            ?>
                                        </td>
                                        <td>
                                            <?= $projects['status'] ?>
                                        </td>
                                        <td>
                                            <?= $projects['priority'] ?>
                                        </td>
                                        <td>
                                            <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded" data-bs-toggle="modal" id="edit-btn" data-bs-target="#edit-modal" data-eid="<?= $projects['id'] ?>" onclick="selectOptions()">Edit</button>
                                        </td>
                                        <td>
                                            <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded delete-btn" data-id="<?= $projects['id'] ?>">Delete</button>
                                        </td>

                                    </tr>
                            <?php }
                            }

                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Content End -->
<!-- content here end -->
<script>

</script>



<!-- Models Start -->
<?php
// footer
include_view("projects/models", $data['users']);
?>
<!-- Models eMD -->



<?php
// yield_data("content");
// footer
include_view("layouts/footer");
?>