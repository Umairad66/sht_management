<?php
    // header
    include_view("layouts/header");

    // sidebar
    include_view("layouts/sidebar");
?>

<!-- content here -->
<h1>Hello</h1>

<?php 
    // yield_data("content");
    // footer
    include_view("layouts/footer");
?>

