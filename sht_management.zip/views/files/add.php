<?php
    // echo "<pre>";
    // print_r($data);
    // exit;
    // header
    include_view("layouts/header");

    // sidebar
    include_view("layouts/sidebar");
?>

<!-- content here start -->

<form action="<?= route("files/add"); ?>" method="post" class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0">Add Task</h4>
            </div>
            <div class="card-body">
               
                <div class="form-group">
                    <label for="name">Name </label>
                    <input id="name" name="name" class="form-control <" type="text" value="">
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" class="form-control " rows="3" id="description" placeholder="Description" spellcheck="false"></textarea>
                </div>

                <div class="form-group">
                    <label for="Team">Team</label>
                    <select name="team_ids" id="Team" class="form-select">
                        <option value="">--Selected Project</option>
                      
                    </select>
                  
                </div>

             
                <div class="form-group">
                    <label for="taskAssign">Task Assign </label>
                    <select name="assigned_to" id="taskAssign" class="form-select">
                        <option value="">--Selected User</option>
                       
                    </select>
                   
                </div>

                <div class="form-group">
                    <label for="priority">Priority </label>
                    <select name="priority" id="priority" class="form-select">
                        <option value="">--Priority</option>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                    </select>
                   
                </div>

              
                <div class="form-group">
                    <label for="status">Status </label>
                    <select name="status" id="status" class="form-select">
                        <option value="">--status</option>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                    </select>
                   
                </div>

              

              
                <div class="form-group">
                    <label for="due_date">Due Date </label>
                    <input id="due_date" name="due_date" class="form-control" type="text" value="">
                   
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </div>
</form>

<!-- content here end -->



<!-- Models Start -->
<?php 
    // footer
    include_view("tasks/models");
?>
<!-- Models eMD -->



<?php 
    // yield_data("content");
    // footer
    include_view("layouts/footer");
?>