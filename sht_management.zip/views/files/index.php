<?php
// header
include_view("layouts/header");
// echo "<pre>";
// print_r($data);
// exit;
// sidebar
include_view("layouts/sidebar");
?>

<!-- content here start -->
<div class="crms-title row bg-white">
    <div class="col  p-0">
        <h3 class="page-title m-0">
            <span class="page-title-icon bg-gradient-primary text-white me-2">
                <i class="feather-check-square"></i>
            </span> Files
        </h3>
    </div>
    <div class="col p-0 text-end">
        <ul class="breadcrumb bg-white float-end m-0 ps-0 pe-0">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Files</li>
        </ul>
    </div>
</div>

<!-- Page Header -->
<div class="page-header pt-3 mb-0 ">
    <div class="row">
        <div class="col">
            <div class="dropdown">
                <a class="dropdown-toggle recently-viewed" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> All Files </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Items I'm following</a>
                    <a class="dropdown-item" href="#">All Completed Files</a>
                    <a class="dropdown-item" href="#">My Delegated Files</a>
                    <a class="dropdown-item" href="#">My Completed Files</a>
                    <a class="dropdown-item" href="#">My Open Files</a>
                    <a class="dropdown-item" href="#">My Files</a>
                    <a class="dropdown-item" href="#">All Files</a>
                </div>
            </div>
        </div>
        <div class="col text-end">
            <ul class="list-inline-item ps-0">
                <li class="nav-item dropdown list-inline-item add-lists">
                    <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="nav-profile-text">
                            <i class="fa fa-th" aria-hidden="true"></i>
                        </div>
                    </a>
                    <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#add-new-list">Add New
                            List View</a>
                    </div>
                </li>
                <li class="list-inline-item">

                    <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded" id="add-task" data-bs-toggle="modal" data-bs-target="#add_file">Add Files</button>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Page Header -->


<!-- Content Starts -->
<div class="row">
    <div class="col-md-12">
        <div class="card mb-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-nowrap custom-table mb-0 datatable">
                        <thead>
                            <tr>
                                <th class="checkBox">
                                    <label class="container-checkbox">
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                    </label>
                                </th>
                                <th>Task Id</th>
                                <th>File Name</th>
                                <th>Uploaded_by</th>
                                <th>Edit</th>
                                <th>Delete</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            if (!empty($data)) {
                                foreach ($data['files'] as $files) {  ?>


                                    <tr>
                                        <td class="checkBox">
                                            <label class="container-checkbox">
                                                <input type="checkbox" name="tasks" value="<?= $files['id'] ?>">
                                                <span class="checkmark"></span>
                                            </label>
                                        </td>

                                        <td>
                                            <?php
                                            $crud = new Models("tasks");
                                            $tasks = $crud->read("id", $files['task_id']);
                                            echo $tasks['name'];
                                            ?>

                                        </td>
                                        <td>
                                            <a href="<?= asset('assets/uploads/' . $files['file_name']) ?>" target="_blank">
                                                <?php
                                                $fileExtension = pathinfo($files['file_name'], PATHINFO_EXTENSION);
                                                $icon = '';
                                                switch ($fileExtension) {
                                                    case 'pdf':
                                                        $icon = 'pdf-icon.png'; // Path to PDF icon image
                                                        break;
                                                    case 'jpg':
                                                    case 'jpeg':
                                                        $icon = 'jpg-icon.png'; // Path to JPEG icon image
                                                        break;
                                                    case 'png':
                                                        $icon = 'png-icon.png'; // Path to PNG icon image
                                                        break;
                                                    case 'txt':
                                                        $icon = 'txt-icon.png'; // Path to text file icon image
                                                        break;
                                                    default:
                                                        $icon = 'default-icon.png'; // Path to default icon image
                                                        break;
                                                }
                                                ?>
                                                <img src="<?= asset('assets/icons/' . $icon) ?>" alt="File name" width="50px">
                                                <span><?= $files['file_name'] ?></span>
                                            </a>
                                        </td>


                                        <td>
                                            <?php
                                            $crud = new Models("users");
                                            $users = $crud->read("id", $files['uploaded_by']);
                                            echo $users['username'];
                                            ?>

                                        </td>
                                        <td>
                                            <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded" data-bs-toggle="modal" id="edit-btn" data-bs-target="#edit_files" data-eid="<?= $files['id'] ?>">Edit</button>
                                        </td>
                                        <td>
                                            <button class="add btn btn-gradient-primary font-weight-bold text-white todo-list-add-btn btn-rounded delete-btn" data-id="<?= $files['id'] ?>">Delete</button>
                                        </td>
                                    </tr>
                            <?php
                                }
                            }

                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Content End -->
<!-- content here end -->




<!-- Models Start -->
<?php
// footer
include_view("files/models", $data);
?>
<!-- Models eMD -->



<?php
// yield_data("content");
// footer
include_view("layouts/footer");
?>